﻿namespace ClasseVivaWPF.SharedControls
{
    public enum ScrollDirections
    {
        Horizontal,
        Vertical
    }
}