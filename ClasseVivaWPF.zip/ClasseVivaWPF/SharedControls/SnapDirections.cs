﻿namespace ClasseVivaWPF.SharedControls
{
    public enum SnapDirections
    {
        Horizontal,
        Vertical
    }
}