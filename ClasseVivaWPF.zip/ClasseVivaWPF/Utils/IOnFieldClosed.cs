﻿namespace ClasseVivaWPF.Utils
{
    public interface IOnChildClosed
    {
        void OnChildClosed();
    }
}
