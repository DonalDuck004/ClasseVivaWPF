﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClasseVivaWPF.Utils
{
    public interface ICVMeta
    {
        bool CountsInStack { get; }
    }
}
