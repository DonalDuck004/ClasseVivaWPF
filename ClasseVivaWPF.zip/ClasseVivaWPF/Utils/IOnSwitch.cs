﻿namespace ClasseVivaWPF.Utils
{
    public interface IOnSwitch
    {
        void OnSwitch();
    }
}
