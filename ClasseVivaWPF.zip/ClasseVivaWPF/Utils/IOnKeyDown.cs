﻿using System.Windows.Input;

namespace ClasseVivaWPF.Utils
{
    public interface IOnKeyDown
    {
        void OnKeyDown(object sender, KeyEventArgs e);
    }
}
