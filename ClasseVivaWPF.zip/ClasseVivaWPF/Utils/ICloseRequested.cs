﻿namespace ClasseVivaWPF.Utils
{
    public interface ICloseRequested
    {
        void OnCloseRequested();
    }
}
