﻿namespace ClasseVivaWPF.HomeControls
{
    /// <summary>
    /// Logica di interazione per cvmENUiCON.xaml
    /// </summary>
    /// 
    public enum CVMainMenuIconValues
    {
        Home,
        Registro,
        Camera,
        Badge,
        Menu
    }
}
