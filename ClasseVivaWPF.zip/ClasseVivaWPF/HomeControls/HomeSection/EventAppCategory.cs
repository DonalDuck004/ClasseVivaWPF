﻿namespace ClasseVivaWPF.HomeControls.HomeSection
{
    public enum EventAppCategory
    {
        Agenda,
        Homework,
    }
}
