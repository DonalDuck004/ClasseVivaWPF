﻿namespace ClasseVivaWPF.HomeControls.RegistrySection.Graphs
{
    public enum CVColumnsGraphFilterOperation
    {
        None,
        GroupSum,
        GroupAVG
    }
}
